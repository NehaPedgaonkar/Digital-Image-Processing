#pragma once

struct LZWentry {
  short prefix;
  short suffix;
};
