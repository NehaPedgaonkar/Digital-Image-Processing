#pragma once

class IContextModel {
public:
  virtual int p() = 0;
};
