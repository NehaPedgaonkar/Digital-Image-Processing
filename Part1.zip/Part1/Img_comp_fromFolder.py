import os
import numpy as np
import cv2
import matplotlib.pyplot as plt

image_folder = '/Users/nehavpedgaonkar/Downloads/greyscale'

image_paths = [os.path.join(image_folder, f) for f in os.listdir(image_folder) if f.endswith(('.png', '.jpg', '.jpeg'))]

compressed_dir = './compressed_files/'
os.makedirs(compressed_dir, exist_ok=True)

global_rmse_values = []
global_bpp_values = []

for img_path in image_paths:
    image_name = os.path.basename(img_path).split('.')[0]
    print(f"\nProcessing {image_name}...")

    image = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)

    if image is None:
        print(f"Error: Unable to load image {img_path}. Skipping...")
        continue

    quality_factors = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
    rmse_values = []
    bpp_values = []

    for qf in quality_factors:
        scaled_quant_matrix = np.clip((QUANTIZATION_MATRIX * (100 / qf)), 1, 255).astype(int)

        encoded_data, huffman_tree, num_blocks, image_shape = jpeg_compression(image, scaled_quant_matrix)

        compressed_file = os.path.join(compressed_dir, f'{image_name}_qf_{qf}.bin')
        with open(compressed_file, 'wb') as f:
            f.write(np.array(image_shape, dtype=np.int32).tobytes())
            f.write(np.array(num_blocks, dtype=np.int32).tobytes())
            f.write(scaled_quant_matrix.flatten().astype(np.int32).tobytes())
            encoded_bytes = bytearray(int(encoded_data[i:i+8], 2) for i in range(0, len(encoded_data), 8))
            f.write(encoded_bytes)

        decompressed_image = jpeg_decompression(encoded_data, huffman_tree, num_blocks, image_shape, scaled_quant_matrix)

        decompressed_file = os.path.join(image_folder, f'{image_name}_qf_{qf}_decompressed.png')
        cv2.imwrite(decompressed_file, decompressed_image)

        rmse = np.sqrt(np.mean((image.astype(np.float32) - decompressed_image.astype(np.float32)) ** 2))
        rmse_values.append(rmse)

        compressed_size = len(open(compressed_file, 'rb').read())
        bpp = compressed_size * 8 / (image.shape[0] * image.shape[1])
        bpp_values.append(bpp)

        print(f"  Quality Factor: {qf}, RMSE: {rmse:.2f}, BPP: {bpp:.2f}")

    global_rmse_values.append(rmse_values)
    global_bpp_values.append(bpp_values)

plt.figure(figsize=(10, 8))
for i, image_name in enumerate([os.path.basename(path).split('.')[0] for path in image_paths]):
    plt.plot(global_bpp_values[i], global_rmse_values[i], marker='o', label=image_name)

plt.title("RMSE vs. BPP for Multiple Images")
plt.xlabel("Bits Per Pixel (BPP)")
plt.ylabel("Root Mean Squared Error (RMSE)")
plt.legend()
plt.grid()
plt.show()

print("Processed all images and generated plots.")
