import cv2
import numpy as np
import subprocess
import struct
import sys
import os

# Step 1: Marr-Hildreth Edge Detection
def marr_hildreth_edge_detection(image_path, low_threshold, high_threshold):

    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise ValueError("Image could not be loaded. Please check the file path.")


    blurred = cv2.GaussianBlur(img, (3, 3), 0.8)  # Smaller kernel liya because thin edges chahiye idk xdxxdfdxdxswiajwiwio
    laplacian = cv2.Laplacian(blurred, cv2.CV_64F)

    #zero crossing implemented below
    zero_crossings = np.zeros_like(laplacian, dtype=np.uint8)
    rows, cols = laplacian.shape

    for i in range(1, rows - 1):
        for j in range(1, cols - 1):
            if laplacian[i, j] == 0:
                if ((laplacian[i - 1, j] > 0 and laplacian[i + 1, j] < 0) or
                    (laplacian[i - 1, j] < 0 and laplacian[i + 1, j] > 0) or
                    (laplacian[i, j - 1] > 0 and laplacian[i, j + 1] < 0) or
                    (laplacian[i, j - 1] < 0 and laplacian[i, j + 1] > 0)):
                    zero_crossings[i, j] = 255
            elif laplacian[i, j] > 0:
                if ((laplacian[i - 1, j] < 0) or (laplacian[i + 1, j] < 0) or
                    (laplacian[i, j - 1] < 0) or (laplacian[i, j + 1] < 0)):
                    zero_crossings[i, j] = 255


    sobelx = cv2.Sobel(blurred, cv2.CV_64F, 1, 0, ksize=1)
    sobely = cv2.Sobel(blurred, cv2.CV_64F, 0, 1, ksize=1)
    gradient_magnitude = np.sqrt(sobelx**2 + sobely**2)
    strong_edges = (gradient_magnitude >= high_threshold)
    weak_edges = ((gradient_magnitude >= low_threshold) & (gradient_magnitude < high_threshold))

    final_edges = np.zeros_like(img, dtype=np.uint8)
    # final_edges[strong_edges] = 255  # Seed points
    for i in range(1, rows - 1):
        for j in range(1, cols - 1):
            if strong_edges[i,j] and zero_crossings[i, j] == 255:
                final_edges[i, j] = 255  # Add weak edges connected to strong edges
            if weak_edges[i, j] and np.any(strong_edges[i - 1:i + 2, j - 1:j + 2]) and zero_crossings[i, j] == 255:
                final_edges[i, j] = 255
                strong_edges[i, j] = True

    return final_edges


# Step 2: Encode Edge Image with JBIG
def encode_with_jbig(input_binary_image_path, jbig_file_path):

    # Need to install JBIG-KIT
    try:
        subprocess.run(["pbmtojbg85", input_binary_image_path, jbig_file_path], check=True)
        print(f"JBIG encoding successful. Saved to {jbig_file_path}")
    except FileNotFoundError:
        raise FileNotFoundError("The `pbmtojbg` tool is not installed or not in PATH.")
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"JBIG encoding failed with error: {e}")

def save_binary_image_as_pbm(binary_image, pbm_file_path):
    cv2.imwrite(pbm_file_path, binary_image)
    print(f"Binary image saved as PBM at {pbm_file_path}")


# Step 3: Extract and Compress Contour Pixel Values
def extract_neighbourhood_values(edge_image_path, color_image_path, q,d):
    edge_image = cv2.imread(edge_image_path, cv2.IMREAD_GRAYSCALE)
    color_image = cv2.imread(color_image_path, cv2.IMREAD_COLOR)    
    if edge_image is None or color_image is None:
        raise FileNotFoundError("Edge or color image not found.")

    edge_pixels = np.argwhere(edge_image == 255)

    offsets = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    count = 0
    # Collect pixel values from neighborhoods
    #very simple funda, wherever there is an edge pixel, take the pixel values of the surrounding pixels, and only store the pixel value
    #of every dth pixel
    #we do not need to store the location, that's the sweet part because the algo is deterministic and points can be determined from the edge image in the same order
    #while decoding
    neighborhood_values = []
    for y, x in edge_pixels:
        for dy, dx in offsets:
            ny, nx = y + dy, x + dx
            if 0 <= ny < color_image.shape[0] and 0 <= nx < color_image.shape[1] and edge_image[ny, nx] != 255:
                if count%d == 0:
                    neighborhood_values.append(color_image[ny, nx])
                count += 1
                # print(color_image[ny, nx])
    
    neighborhood_values = np.array(neighborhood_values)
    
    factor = 256 // (2 ** q)
    quantized_values = (neighborhood_values // factor).astype(np.uint8)
    # quantized_values = quantized_values[::d]
    
    return quantized_values

def save_to_binary_file(data, file_path):
    data.tofile(file_path)

def compress_with_paq(binary_file_path, compressed_file_path, paq_executable_path="paq8px208fix1", compression_level=8):
    subprocess.run(["paq8px", f"-{compression_level}", binary_file_path, compressed_file_path], check=True)


# Step 4: Encode File
def read_data_as_bytes(file_path):
    try:
        with open(file_path, "rb") as file:
            return file.read()
    except UnicodeDecodeError:
        # If the file is not directly readable as binary
        with open(file_path, "r") as file:
            return file.read().encode("utf-8")


def encode_image_file(jbig_data_path, paq_data_path, output_file_path, num_channels, quantization_q, sampling_d):
    jbig_data = read_data_as_bytes(jbig_data_path)
    jbig_size = len(jbig_data)

    # Read PAQ data and convert to bytes
    paq_data = read_data_as_bytes(paq_data_path)

    # Create header
    # - JBIG size (4 bytes)
    # - Number of channels (1 byte)
    # - Quantization parameter q (1 byte)
    # - Sampling distance d (3 bytes)
    header = struct.pack(
        ">I B B 3s",  # Format: 4 bytes (JBIG size), 1 byte (num_channels), 1 byte (q), 3 bytes (d)
        jbig_size,
        num_channels,
        quantization_q,
        sampling_d.to_bytes(3, byteorder="big"),
    )

    with open(output_file_path, "wb") as output_file:
        output_file.write(header)  
        output_file.write(jbig_data)  
        output_file.write(paq_data)  

    print(f"File encoded successfully and saved to {output_file_path}")


# Main Workflow
def main():
    # Command-line arguments
    if len(sys.argv) != 4:
        print("Usage: python encoder.py <image_path> <quantization_q> <sampling_d>")
        sys.exit(1)

    image_path = sys.argv[1]
    quantization_q = int(sys.argv[2])
    sampling_d = int(sys.argv[3])
    os.makedirs("tmp", exist_ok=True)
    edge_image_path = "tmp/edges.pbm"
    jbig_file_path = "tmp/edges.jbg"
    binary_file_path = "tmp/quantized_data.bin"
    compressed_file_path = "tmp/compressed_data.paq8px208fix1"
    encoded_file_path = "encoded_image_file.bin"

    # Step 1: Marr-Hildreth Edge Detection
    low_threshold = 8
    high_threshold = 10
    edges = marr_hildreth_edge_detection(image_path, low_threshold, high_threshold)
    cv2.imwrite(edge_image_path, edges)

    # Step 2: Encode Edge Image with JBIG
    encode_with_jbig(edge_image_path, jbig_file_path)

    # Step 3: Extract and Compress Contour Pixel Values
    pixel_values = extract_neighbourhood_values(edge_image_path, image_path, quantization_q, sampling_d)
    save_to_binary_file(pixel_values, binary_file_path)
    compress_with_paq(binary_file_path, compressed_file_path)

    # Step 4: Encode File
    encode_image_file(jbig_file_path, compressed_file_path, encoded_file_path, 3, quantization_q, sampling_d)


if __name__ == "__main__":
    main()
