import struct
import subprocess
import cv2
import numpy as np
import os
import sys

# Step 1: Decode the Encoded File
def decode_image_file(encoded_file_path, jbig_output_path, paq_output_path):
    """
    Decodes an encoded image file into its components (header, JBIG data, PAQ data).

    Args:
        encoded_file_path (str): Path to the encoded image file.
        jbig_output_path (str): Path to save the extracted JBIG data in its specific format.
        paq_output_path (str): Path to save the extracted PAQ data in its specific format.

    Returns:
        dict: Parsed header information.
    """
    with open(encoded_file_path, "rb") as encoded_file:
        # Read the header
        header_format = ">I B B 3s"  # 4 bytes (JBIG size), 1 byte (num_channels), 1 byte (q), 3 bytes (d)
        header_size = struct.calcsize(header_format)
        header_data = encoded_file.read(header_size)
        jbig_size, num_channels, quantization_q, sampling_d = struct.unpack(header_format, header_data)
        sampling_d = int.from_bytes(sampling_d, byteorder="big")  # Convert 3-byte sampling distance to integer

        print(f"Decoded Header:")
        print(f"  JBIG Data Size: {jbig_size} bytes")
        print(f"  Number of Channels: {num_channels}")
        print(f"  Quantization Parameter (q): {quantization_q}")
        print(f"  Sampling Distance (d): {sampling_d}")

        # Read JBIG data
        jbig_data = encoded_file.read(jbig_size)

        # Read remaining data as PAQ data
        paq_data = encoded_file.read()

    # Save JBIG data to file in its specific format
    with open(jbig_output_path, "wb") as jbig_file:
        jbig_file.write(jbig_data)
    print(f"JBIG data saved to {jbig_output_path}")

    # Save PAQ data to file in its specific format
    with open(paq_output_path, "wb") as paq_file:
        paq_file.write(paq_data)
    print(f"PAQ data saved to {paq_output_path}")

    # Return header information
    return {
        "jbig_size": jbig_size,
        "num_channels": num_channels,
        "quantization_q": quantization_q,
        "sampling_d": sampling_d,
    }


# Step 2: Convert JBIG to PNG
def convert_jbg_to_png(jbg_file_path, output_png_path):
    pbm_file_path = "temp.pbm"  # Temporary PBM file
    try:
        subprocess.run(["jbgtopbm85", jbg_file_path, pbm_file_path], check=True)
        subprocess.run(["convert", pbm_file_path, output_png_path], check=True)
        print(f"Converted JBIG to PNG as {output_png_path}")
    finally:
        if os.path.exists(pbm_file_path):
            os.remove(pbm_file_path)


# Step 3: Decompress and Overlay Quantized Data
def decompress_with_paq(compressed_file_path, decompressed_file_path):
    subprocess.run(["paq8px", "-d", compressed_file_path,decompressed_file_path], check=True)


def load_quantized_data(binary_file_path, q, shape):
    factor = 256 // (2 ** q)
    data = np.fromfile(binary_file_path, dtype=np.uint8)
    return (data.reshape(shape) * factor).astype(np.uint8)


def overlay_edges_and_pixels(edge_image_path, quantized_data, output_path, d):
    edge_image = cv2.imread(edge_image_path, cv2.IMREAD_GRAYSCALE)
    output_image = np.zeros((edge_image.shape[0], edge_image.shape[1], 3), dtype=np.uint8)
    edge_pixels = np.argwhere(edge_image == 255)
    offsets = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    idx = 0
    count = 0
    for y, x in edge_pixels:
        for dy, dx in offsets:
            ny, nx = y + dy, x + dx
            if 0 <= ny < edge_image.shape[0] and 0 <= nx < edge_image.shape[1] and edge_image[ny, nx] != 255:
                if count%d == 0 and idx < len(quantized_data):
                    output_image[ny, nx] = quantized_data[idx]
                    idx += 1
                count += 1
    cv2.imwrite(output_path, output_image)
    return output_image


# Step 4: Perform Inpainting
def inpaint_image(input_image_path, edge_image_path, output_image_path):
    # Skill issue that I could not implement the last paper from scratch as is from the paper and had to use OpenCV
    # Paper intends to implement this using iterations over the edge pixels and linear interpolation using the solution to PDE for zero Laplacian
    image = cv2.imread(input_image_path, cv2.IMREAD_COLOR)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    _, mask = cv2.threshold(gray, 1, 255, cv2.THRESH_BINARY_INV)
    inpainted_image = cv2.inpaint(image, mask, inpaintRadius=3, flags=cv2.INPAINT_TELEA)
    cv2.imwrite(output_image_path, inpainted_image)
    print(f"Inpainting completed. Saved as {output_image_path}")


# Main Workflow
def main():
    # File paths
    if len(sys.argv) != 2:
        print("Usage: python decoder.py <encoded_file_path>")
        sys.exit(1)
    os.makedirs("tmp", exist_ok=True)
    encoded_file_path = image_path = sys.argv[1]
    jbig_output_path = "tmp/decoded_jbig_data.jbg"
    paq_output_path = "tmp/decoded_paq_data.paq8px208fix1"
    edge_image_path = "tmp/decoded_edge_image.png"
    decompressed_file_path = "tmp/decompressed_data.bin"
    reconstructed_image_path = "tmp/reconstructed_image.png"
    final_image_path = "final_image.png"

    # Step 1: Decode the encoded file
    header_info = decode_image_file(encoded_file_path, jbig_output_path, paq_output_path)

    # Step 2: Convert JBIG to PNG
    convert_jbg_to_png(jbig_output_path, edge_image_path)

    # Step 3: Decompress PAQ and overlay pixel values
    decompress_with_paq(paq_output_path, decompressed_file_path)
    quantized_data = load_quantized_data(decompressed_file_path, header_info["quantization_q"], (-1, 3))
    overlay_edges_and_pixels(edge_image_path, quantized_data, reconstructed_image_path, header_info["sampling_d"])

    # Step 4: Perform inpainting to reconstruct the missing regions
    inpaint_image(reconstructed_image_path, edge_image_path, final_image_path)


if __name__ == "__main__":
    main()
